import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  Image,
  FlatList,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import * as Location from 'expo-location';
import Icon from 'react-native-vector-icons/Ionicons';

const categories = [
  {
    id: '1',
    name: 'Frutas',
    bgColor: '#d4eac7',
    image: 'https://img.icons8.com/emoji/96/avocado-emoji.png',
  },
  {
    id: '2',
    name: 'Diversos',
    bgColor: '#b2c9f6',
    image: 'https://img.icons8.com/emoji/96/chocolate-bar-emoji.png',
  },
  {
    id: '3',
    name: 'Açougue',
    bgColor: '#f3c7c3',
    image: 'https://img.icons8.com/emoji/96/poultry-leg-emoji.png',
  },
  {
    id: '4',
    name: 'Bebidas',
    bgColor: '#a6f2f1',
    image: 'https://img.icons8.com/emoji/96/bubble-tea.png',
  },
];

const ProductScreen = () => {
  const [location, setLocation] = useState('Carregando...');
  const [search, setSearch] = useState('');

  useEffect(() => {
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setLocation('Permissão negada');
        return;
      }

      const loc = await Location.getCurrentPositionAsync({});
      const address = await Location.reverseGeocodeAsync(loc.coords);

      if (address.length > 0) {
        const { city, region } = address[0];
        setLocation(`${city}, ${region}`);
      }
    })();
  }, []);

  const renderCategory = ({ item }) => (
    <TouchableOpacity
      style={[styles.categoryCard, { backgroundColor: item.bgColor }]}>
      <Image source={{ uri: item.image }} style={styles.categoryImage} />
      <Text style={styles.categoryText}>{item.name}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      {/* Top bar */}
      <View style={styles.topBar}>
        <View style={styles.locationContainer}>
          <Icon name="location-outline" size={18} />
          <Text style={styles.locationText}>{location}</Text>
        </View>
        <Image
          source={{ uri: 'https://i.pravatar.cc/100' }}
          style={styles.avatar}
        />
      </View>

      {/* Search bar */}
      <View style={styles.searchContainer}>
        <TextInput
          style={styles.searchInput}
          placeholder="Buscar produtos..."
          value={search}
          onChangeText={setSearch}
        />
        <Icon name="search" size={20} color="#888" />
      </View>

      {/* Categories */}
      <FlatList
        data={categories}
        renderItem={renderCategory}
        keyExtractor={(item) => item.id}
        numColumns={2}
        columnWrapperStyle={styles.categoryRow}
        contentContainerStyle={{ paddingBottom: 100 }}
      />
    </View>
  );
};

const CARD_WIDTH = (Dimensions.get('window').width - 60) / 2;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: 50,
    paddingHorizontal: 20,
    backgroundColor: '#fff',
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  locationText: {
    marginLeft: 6,
    fontSize: 14,
  },
  avatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  searchContainer: {
    flexDirection: 'row',
    backgroundColor: '#f0f0f0',
    borderRadius: 10,
    paddingHorizontal: 10,
    alignItems: 'center',
    height: 40,
    marginBottom: 20,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
  },
  categoryRow: {
    justifyContent: 'space-between',
    marginBottom: 15,
  },
  categoryCard: {
    width: CARD_WIDTH,
    height: 90,
    borderRadius: 10,
    padding: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  categoryImage: {
    width: 40,
    height: 40,
    resizeMode: 'contain',
    marginRight: 10,
  },
  categoryText: {
    fontSize: 16,
  },
});

export default ProductScreen;
