import React from 'react';
import { Ionicons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

export default function Home({ navigation }) {
  return (
    <View style={styles.container}>
      <Image
        source={require('assets/img-sacola.png')}
        style={{ width: 250, height: 400 }}
      />
      <Text style={styles.title}>Entregamos mantimentos à {'\n'}sua porta</Text>
      <Text>A mercearia oferece vegetais e frutas frescas.</Text>
      <Text>Encomenda itens frescos na mercearia.</Text>
      <TouchableOpacity
        style={styles.button}
        onPress={() => navigation.navigate('Product')}>
        <Text style={styles.buttonText}>INICIAR </Text>
        <Ionicons name="arrow-forward" size={12} color="white" />
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    margin: 0,
  },

  title: {
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  button: {
    backgroundColor: '#7785DB',
    paddingVertical: 16,
    paddingHorizontal: 24,
    borderRadius: 30,
    flexDirection: 'row',
  },
  buttonText: {
    fontFamily: 'arial',
    color: 'white',
    fontSize: 12,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
